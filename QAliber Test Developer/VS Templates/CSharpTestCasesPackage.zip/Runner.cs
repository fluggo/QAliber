using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    /// <summary>
    /// This class provides a way for debugging your test cases code.
    /// Before deploying your test cases project, please remove this file, and 
    /// set the project properties to 'Class Library'
    /// </summary>
    public class Runner
    {
        [STAThread]
        public static void Main()
        {
            using (QAliber.Logger.Log.Default)
            {
                QAliber.Logger.Log.Default.Filename = "TestCasesLog.log";
                try
                {
                    Console.WriteLine("Debugging Test Cases...");
                    //Enter here the test cases you want to debug
                    new MyTestCase().Body();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception caught : " + ex.Message + "\n" + ex.StackTrace);
                }
                finally
                {
                    Console.WriteLine("... Debugging Ended");
                }

            }
            Console.WriteLine("Press any enter to exit...");
            Console.ReadLine();
        }
    }
}
