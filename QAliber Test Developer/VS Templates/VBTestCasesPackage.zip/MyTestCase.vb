Imports QAliber.Engine
Imports QAliber.Engine.Controls
Imports QAliber.Engine.Controls.UIA
Imports QAliber.Engine.Controls.Web
Imports QAliber.Engine.Controls.WPF
Imports QAliber.Logger
Imports QAliber.TestModel
Imports QAliber.RemotingModel

Imports System.Windows
Imports System.Windows.Forms

<Serializable()> _
<QAliber.TestModel.Attributes.VisualPath("My Test Cases")> _
Public Class MyTestCase
    Inherits QAliber.TestModel.TestCase

    Public Sub New()
        Me.Name = "My Test Case"
        Me.Icon = Nothing
    End Sub

    Public Overrides Property Description() As String
        Get
            Return MyBase.Description
        End Get
        Set(ByVal value As String)
            MyBase.Description = value
        End Set
    End Property

    Public Overrides Sub Body()
        'TODO: Add the test implementation here
    End Sub
End Class
