Module Runner

    ''' <summary>
    ''' This class provides a way for debugging your test cases code.
    ''' Before deploying your test cases project, please remove this file, and 
    ''' set the project properties to 'Class Library'
    ''' </summary>
    <STAThread()> _
    Sub Main()
        QAliber.Logger.Log.Default.Filename = "TestCasesLog.qlog"
        Try
            Console.WriteLine("Debugging Test Cases...")
            'Enter here the test cases you want to debug
            Dim testcase As New MyTestCase()
            testcase.Body()

        Catch ex As Exception
            Console.WriteLine("Exception caught : " + ex.Message + "\n" + ex.StackTrace)
        Finally
            Console.WriteLine("... Debugging Ended")
            QAliber.Logger.Log.Default.Dispose()
            Console.WriteLine("Press any enter to exit...")
            Console.ReadLine()
        End Try
    End Sub

End Module
