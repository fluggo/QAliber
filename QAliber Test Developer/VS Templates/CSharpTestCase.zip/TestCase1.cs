using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Forms;

using QAliber.Engine;
using QAliber.Engine.Controls;
using QAliber.Engine.Controls.UIA;
using QAliber.Engine.Controls.Web;
using QAliber.Engine.Controls.WPF;
using QAliber.Logger;
using QAliber.TestModel;
using QAliber.RemotingModel;

namespace $rootnamespace$
{
    [Serializable]
    [QAliber.TestModel.Attributes.VisualPath("My Test Cases")]
    public class $safeitemname$ : TestCase
    {
        public $safeitemname$()
        {
            name = "$safeitemname$";
            description = "";
            expectedResult = TestCaseResult.None;
            icon = null;
        }

        public override void Body()
        {
            //TODO: Add the test implementation here
        }
    }
}
